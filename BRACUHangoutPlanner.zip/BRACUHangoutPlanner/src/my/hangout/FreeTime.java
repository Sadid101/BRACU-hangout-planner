/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.hangout;

/**
 *
 * @author Sahanara Khatun
 */
public class FreeTime {
    Variables v;
    static String sun="";
    static String mon="";
    static String tue="";
    static String wed="";
    static String thurs="";
    static String sat="";
    FreeTime(){
    for(int j=0; j<6; j++){
            String s="";
            for(int i=0; i<7; i++){
                if(Variables.data[i][j]==0){
                    if(i==0){
                        s+=" 8:00-9:30";
                    }
                    else if(i==1){
                        s+=" 9:30-11:00";
                    }
                    else if(i==2){
                        s+=" 11:00-12:30";
                    }
                    else if(i==3){
                        s+=" 12:30-2:00";
                    }
                    else if(i==4){
                        s+=" 2:00-3:30";
                    }
                    else if(i==5){
                        s+=" 3:30-5:00";
                    }
                    else{
                        if(s==""){
                            s+=" Not free today";
                        }
                    }
                }
                }
                if(j==0){
                    sun=s;
                }
                else if(j==1){
                    mon=s;
                }
                else if(j==2){
                    tue=s;
                }
                else if(j==3){
                    wed=s;
                }
                else if(j==4){
                    thurs=s;
                }
                else if(j==5){
                    sat=s;
                }
            }
    }
    }
    
    

