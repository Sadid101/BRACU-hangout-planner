/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.hangout;

/**
 *
 * @author Sahanara Khatun
 */
class Variables {
    public static int[][] data=new int[7][6];
    public static Node head;
    public static String name;
    
}
