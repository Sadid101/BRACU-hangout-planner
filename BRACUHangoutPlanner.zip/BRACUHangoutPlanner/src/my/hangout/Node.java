/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.hangout;

/**
 *
 * @author Sahanara Khatun
 */
public class Node {
  Object elem;
  Node next;
  Node down;
  String name1;
  Node(Object e,Node n){
    elem = e;
    next = n;
  }
  Node(String a){
      name1=a;
  }
}
